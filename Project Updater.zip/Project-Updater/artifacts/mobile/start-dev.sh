#!/bin/sh
# Start API server (port 8080) in background, then start Expo in foreground.
# Both run in the Expo workflow cgroup — server persists as long as Expo runs.
# When Expo workflow restarts, API server also restarts automatically.

API_DIR="/home/runner/workspace/artifacts/api-server"
API_SERVER="$API_DIR/dist/index.cjs"
API_LOG="/tmp/api-server.log"

start_api() {
  echo "[dev] Building API server..."
  (cd "$API_DIR" && pnpm run build) 2>&1
  echo "[dev] Starting API server on :8080..."
  PORT=8080 NODE_ENV=development node "$API_SERVER" >> "$API_LOG" 2>&1 &
  i=0
  while [ $i -lt 12 ]; do
    sleep 1
    if curl -sf http://localhost:8080/api/healthz >/dev/null 2>&1; then
      echo "[dev] API server is up on :8080"
      return 0
    fi
    i=$((i + 1))
  done
  echo "[dev] Warning: API server did not respond in 12s — Expo starting anyway"
}

# Background monitor: restart API server if it dies
monitor_api() {
  while true; do
    sleep 30
    if ! curl -sf http://localhost:8080/api/healthz >/dev/null 2>&1; then
      echo "[dev] API server died — restarting..."
      PORT=8080 NODE_ENV=development node "$API_SERVER" >> "$API_LOG" 2>&1 &
      sleep 5
    fi
  done
}

start_api
monitor_api &

exec env \
  EXPO_PACKAGER_PROXY_URL="https://$REPLIT_EXPO_DEV_DOMAIN" \
  EXPO_PUBLIC_DOMAIN="$REPLIT_DEV_DOMAIN" \
  EXPO_PUBLIC_REPL_ID="$REPL_ID" \
  REACT_NATIVE_PACKAGER_HOSTNAME="$REPLIT_DEV_DOMAIN" \
  pnpm exec expo start --localhost --port "$PORT"
