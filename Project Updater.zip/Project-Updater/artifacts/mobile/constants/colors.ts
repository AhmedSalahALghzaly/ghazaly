// template
const tintColorLight = "#2f95dc";

export default {
  light: {
    text: "#000",
    background: "#fff",
    tint: tintColorLight,
    tabIconDefault: "#ccc",
    tabIconSelected: tintColorLight,
    foreground: "#000",
    mutedForeground: "#6b7280",
    primary: tintColorLight,
    primaryForeground: "#fff",
    border: "#e5e7eb",
    card: "#f9fafb",
  },
  radius: 8,
};
