import { useState, useEffect, useRef, useCallback } from 'react';
import { chatApi } from '../services/api';
import { useAppStore } from '../store/appStore';

export interface Message {
  id: string;
  conversation_id: string;
  sender_type: 'customer' | 'admin' | 'owner' | 'ai_agent';
  content: string;
  message_type: string;
  file_url?: string;
  is_read: boolean;
  created_at: string;
}

export interface Conversation {
  id: string;
  user_id?: string;
  user_name?: string;
  user_email?: string;
  user_role?: string;
  type: string;
  status: string;
  unread_count: number;
  last_message?: string;
  last_message_at?: string;
  created_at: string;
  updated_at?: string;
  ai_auto_reply?: boolean;
}

function buildWsUrl(sessionToken?: string | null) {
  const base = process.env.EXPO_PUBLIC_DOMAIN
    ? `wss://${process.env.EXPO_PUBLIC_DOMAIN}/api/ws`
    : 'ws://localhost:8080/api/ws';
  // Pass the session token so the server can validate it server-side (never the user_id directly)
  return sessionToken ? `${base}?token=${encodeURIComponent(sessionToken)}` : base;
}

export function useChat() {
  const user = useAppStore((s) => s.user);
  const userRole = useAppStore((s) => s.userRole);

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [deletedConversations, setDeletedConversations] = useState<Conversation[]>([]);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [aiMessages, setAiMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  const wsRef = useRef<WebSocket | null>(null);
  const isMountedRef = useRef(true);
  const aiConversationIdRef = useRef<string | null>(null);
  // Keep a ref so the WS handler always sees the latest activeConversation
  const activeConversationRef = useRef<Conversation | null>(null);
  // Tracks ai_auto_reply state per conversation (keyed by conversation id)
  // Updated when conversations load and when the admin toggles the switch
  const aiAutoReplyRef = useRef<Record<string, boolean>>({});
  // Dedup set: prevents a message from triggering more than one auto-reply
  // (handles reconnect + replayed WS events). Entries expire after 5 min.
  const processedAutoReplyRef = useRef<Set<string>>(new Set());
  // Mirror of isPrivileged as a ref so the WS closure always reads latest value
  const isPrivilegedRef = useRef(false);

  const isPrivileged = userRole === 'admin' || userRole === 'owner';

  // Keep isPrivilegedRef in sync so the WS closure reads the latest value
  useEffect(() => {
    isPrivilegedRef.current = isPrivileged;
  }, [isPrivileged]);

  const sessionToken = useAppStore((s) => s.sessionToken);

  const connectWs = useCallback(() => {
    if (!isMountedRef.current) return;
    if (wsRef.current?.readyState === WebSocket.OPEN) return;
    try {
      const ws = new WebSocket(buildWsUrl(sessionToken));
      wsRef.current = ws;
      ws.onmessage = (evt) => {
        if (!isMountedRef.current) return;
        try {
          const data = JSON.parse(evt.data);
          if (data.type === 'chat_message' || data.type === 'ai_message') {
            const msg: Message = data.message;
            const activeCid = activeConversationRef.current?.id ?? null;
            // Append to message list if it belongs to the currently open conversation
            setMessages((prev) => {
              if (prev.find((m) => m.id === msg.id)) return prev;
              if (activeCid && msg.conversation_id === activeCid) {
                return [...prev, msg];
              }
              return prev;
            });
            // Instantly update last_message + unread_count in conversations list
            setConversations((prev) =>
              prev.map((c) =>
                c.id === msg.conversation_id
                  ? {
                      ...c,
                      last_message: msg.content || c.last_message,
                      last_message_at: msg.created_at,
                      updated_at: msg.created_at,
                      // Only increment unread for conversations NOT currently open
                      unread_count: activeCid === msg.conversation_id ? c.unread_count : (c.unread_count ?? 0) + 1,
                    }
                  : c,
              ),
            );
            loadUnreadCount();
            loadConversations();

            // ── AI AUTO-REPLY TRIGGER ─────────────────────────────────────────
            // Only fire when:
            //   1. Current user is privileged (admin/owner)
            //   2. Incoming message is from a customer (not self, not AI)
            //   3. The conversation has AI auto-reply enabled (local toggle state)
            //   4. This message has not already been attempted locally (pre-flight dedup)
            //
            // Server-side idempotency: /chat/auto-reply atomically flips
            // ai_auto_reply_sent on the message row (UPDATE ... WHERE ... = FALSE
            // RETURNING id). Only the first caller wins; all others get { skipped }.
            // This prevents duplicate replies even when multiple privileged users
            // are connected simultaneously.
            // If toggle state is not yet known for this conversation (startup race),
            // still attempt the call — the server reads the DB flag directly and
            // will skip if ai_auto_reply is false on the conversation.
            const toggleKnown = msg.conversation_id in aiAutoReplyRef.current;
            const toggleEnabled = !toggleKnown || aiAutoReplyRef.current[msg.conversation_id] === true;
            if (
              isPrivilegedRef.current &&
              msg.sender_type === 'customer' &&
              toggleEnabled &&
              !processedAutoReplyRef.current.has(msg.id)
            ) {
              processedAutoReplyRef.current.add(msg.id);
              // Expire local dedup entry after 5 min to prevent memory growth
              setTimeout(() => processedAutoReplyRef.current.delete(msg.id), 5 * 60 * 1000);

              (async () => {
                try {
                  await chatApi.triggerAutoReply({
                    message_id: msg.id,
                    conversation_id: msg.conversation_id,
                  });
                  // Server broadcasts the AI reply via WS — no further action needed
                } catch (e) {
                  console.error('[AutoReply] trigger failed:', e);
                }
              })();
            }
            // ── END AUTO-REPLY TRIGGER ────────────────────────────────────────
          }
        } catch {}
      };
      ws.onerror = () => {};
      ws.onclose = () => {
        if (isMountedRef.current) {
          setTimeout(connectWs, 3000);
        }
      };
    } catch {}
  }, [sessionToken]);

  useEffect(() => {
    isMountedRef.current = true;
    if (user) {
      connectWs();
    }
    return () => {
      isMountedRef.current = false;
      wsRef.current?.close();
      wsRef.current = null;
    };
  }, [user]);

  const loadUnreadCount = useCallback(async () => {
    try {
      const res = await chatApi.getUnreadCount();
      setUnreadCount(res.data?.unread_count ?? 0);
    } catch {}
  }, []);

  const loadConversations = useCallback(async () => {
    setLoading(true);
    try {
      const res = await chatApi.getConversations();
      const data: Conversation[] = Array.isArray(res.data) ? res.data : (res.data?.conversations ?? []);
      setConversations(data);
      // Seed aiAutoReplyRef — preserve any explicitly-toggled state (don't overwrite existing keys)
      data.forEach((c) => {
        if (!(c.id in aiAutoReplyRef.current)) {
          aiAutoReplyRef.current[c.id] = c.ai_auto_reply !== false;
        }
      });
    } catch {
      setConversations([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadDeletedConversations = useCallback(async () => {
    try {
      const res = await chatApi.getDeletedConversations();
      const data = Array.isArray(res.data) ? res.data : (res.data?.conversations ?? []);
      setDeletedConversations(data);
    } catch {
      setDeletedConversations([]);
    }
  }, []);

  const loadMessages = useCallback(async (conversationId: string) => {
    setLoading(true);
    try {
      const res = await chatApi.getMessages(conversationId);
      const data = Array.isArray(res.data) ? res.data : (res.data?.messages ?? []);
      setMessages(data);
      await chatApi.markMessagesRead(conversationId);
      loadUnreadCount();
    } catch {
      setMessages([]);
    } finally {
      setLoading(false);
    }
  }, [loadUnreadCount]);

  const openConversation = useCallback(async (conv: Conversation) => {
    activeConversationRef.current = conv;
    setActiveConversation(conv);
    await loadMessages(conv.id);
  }, [loadMessages]);

  const sendMessage = useCallback(async (content: string, message_type = 'text', file_url?: string) => {
    // Allow media/file sends with empty text (file_url provided); block only pure empty-text sends
    const hasMedia = !!file_url && message_type !== 'text';
    if (!activeConversation || (!content.trim() && !hasMedia) || sending) return;
    const convId = activeConversation.id;
    const tempId = `temp-${Date.now()}`;
    // Optimistic update — show message immediately before server round-trip
    // Use the actual role so the bubble renders on the correct side with correct colour
    const senderType: Message['sender_type'] =
      userRole === 'owner' ? 'owner' :
      userRole === 'admin' ? 'admin' :
      'customer';
    const optimistic: Message = {
      id: tempId,
      conversation_id: convId,
      sender_type: senderType,
      content: content.trim(),
      message_type,
      file_url,
      is_read: true,
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimistic]);
    setSending(true);
    try {
      await chatApi.sendMessage({ conversation_id: convId, content: content.trim(), message_type, file_url });
      await loadMessages(convId);
    } catch (e) {
      // Remove optimistic message on error
      setMessages((prev) => prev.filter((m) => m.id !== tempId));
    } finally {
      setSending(false);
    }
  }, [activeConversation, sending, loadMessages]);

  const getOrCreateCustomerConversation = useCallback(async () => {
    setLoading(true);
    try {
      const res = await chatApi.getConversations();
      const convs: Conversation[] = Array.isArray(res.data) ? res.data : (res.data?.conversations ?? []);
      if (convs.length > 0) {
        setConversations(convs);
        await openConversation(convs[0]);
      } else {
        const created = await chatApi.createConversation({ type: 'customer_support' });
        const newConv: Conversation = created.data?.conversation ?? created.data;
        setConversations([newConv]);
        await openConversation(newConv);
      }
    } catch {} finally {
      setLoading(false);
    }
  }, [openConversation]);

  const sendAiMessage = useCallback(async (content: string) => {
    if (!content.trim() || sending) return;
    const userMsg: Message = {
      id: `temp-${Date.now()}`,
      conversation_id: aiConversationIdRef.current ?? '',
      sender_type: 'customer',
      content: content.trim(),
      message_type: 'text',
      is_read: true,
      created_at: new Date().toISOString(),
    };
    setAiMessages((prev) => [...prev, userMsg]);
    setSending(true);
    try {
      const res = await chatApi.sendAiMessage({
        message: content.trim(),
        conversation_id: aiConversationIdRef.current ?? undefined,
      });
      const reply = res.data;
      if (reply?.conversation_id) {
        aiConversationIdRef.current = reply.conversation_id;
      }
      const aiMsg: Message = {
        id: `ai-${Date.now()}`,
        conversation_id: reply?.conversation_id ?? '',
        sender_type: 'ai_agent',
        content: reply?.response ?? reply?.message ?? 'عذراً، حدث خطأ.',
        message_type: 'text',
        is_read: true,
        created_at: new Date().toISOString(),
      };
      setAiMessages((prev) => [...prev, aiMsg]);
    } catch {
      const errMsg: Message = {
        id: `err-${Date.now()}`,
        conversation_id: '',
        sender_type: 'ai_agent',
        content: 'عذراً، حدث خطأ في الاتصال بالمساعد.',
        message_type: 'text',
        is_read: true,
        created_at: new Date().toISOString(),
      };
      setAiMessages((prev) => [...prev, errMsg]);
    } finally {
      setSending(false);
    }
  }, [sending]);

  const restoreConversation = useCallback(async (id: string) => {
    try {
      await chatApi.restoreConversation(id);
      await loadDeletedConversations();
      await loadConversations();
    } catch {}
  }, [loadDeletedConversations, loadConversations]);

  const archiveConversation = useCallback(async (id: string) => {
    await chatApi.updateConversationStatus(id, 'deleted');
    await loadConversations();
    await loadDeletedConversations();
  }, [loadConversations, loadDeletedConversations]);

  const permanentlyDeleteConversation = useCallback(async (id: string) => {
    try {
      await chatApi.permanentlyDeleteConversation(id);
      setDeletedConversations((prev) => prev.filter((c) => c.id !== id));
    } catch {}
  }, []);

  return {
    user,
    userRole,
    isPrivileged,
    conversations,
    deletedConversations,
    activeConversation,
    messages,
    aiMessages,
    loading,
    sending,
    unreadCount,
    setActiveConversation: (conv: Conversation | null) => {
      activeConversationRef.current = conv;
      setActiveConversation(conv);
    },
    loadConversations,
    loadDeletedConversations,
    loadUnreadCount,
    openConversation,
    sendMessage,
    sendAiMessage,
    setAiConversationId: (id: string | null) => { aiConversationIdRef.current = id; },
    getOrCreateCustomerConversation,
    restoreConversation,
    archiveConversation,
    permanentlyDeleteConversation,
    // Update ai_auto_reply state for a specific conversation in the ref
    // Called by DirectChatTab when the admin toggles the AI indicator
    setConvAiAutoReply: (convId: string, enabled: boolean) => {
      aiAutoReplyRef.current[convId] = enabled;
    },
  };
}
